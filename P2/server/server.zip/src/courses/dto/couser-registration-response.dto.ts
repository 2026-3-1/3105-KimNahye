export class CourseRegistrationResponse {}
