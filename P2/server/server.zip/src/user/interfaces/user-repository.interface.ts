import { User } from '../entities/user.entity';

export interface IUserRepository {
  findByEmail(email: string): Promise<User | null>;
  findById(id: string): Promise<User | null>;
  findByEmailWithPassword(email: string): Promise<User | null>;
  create(userData: Partial<User>): Promise<User>;
  save(user: User);
}

export const USER_REPOSITORY = Symbol('IUserRepository');
